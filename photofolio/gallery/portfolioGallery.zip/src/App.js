import Home from "./components/Home/Home";
import NewUser from "./components/NewUser/NewUser";
import PortfolioGallery from "./components/PortfolioGallery/PortfolioGallery";

function App() {
  return (
    <div>
      <PortfolioGallery />
    </div>
  );
}

export default App;
