import NewUser from "./components/NewUser/NewUser";

function App() {
  return (
    <div>
      <NewUser />
    </div>
  );
}

export default App;
